<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css?family=Muli:400,500,600,700&display=swap" rel="stylesheet">
        <title></title>
    </head>
    <body style="margin: 0px; padding: 0px; background-color: #ffffff; width: 100%; -webkit-text-size-adjust: none; -ms-text-size-adjust: none; text-size-adjust: none; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; padding:0; margin: 0; min-width: 100%">
        <div class="preheader" style="font-size: 0; padding: 0; display: none; max-height: 0; mso-hide: all; line-height: 0; color: transparent; height: 0; max-width: 0; opacity: 0; overflow: hidden; visibility: hidden; width: 0;"></div>
        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
                <td align="center" bgcolor="#efedf0" style="background-color:#efedf0;vertical-align:top;padding:0px 0px 0px 0px;">
                    <table bgcolor="#efedf0" border="0" cellpadding="0" cellspacing="0" class="tbl_main" style="min-width:540px;width:540px;background-color:#efedf0;" width="540">
                        <tr>
                            <td align="center" style="border-collapse:collapse;padding:60px 0px 60px 0px;" valign="top" class="Pad_LR10">
                                <table align="center" bgcolor="#efedf0" border="0" cellpadding="0" cellspacing="0" style="" width="100%">
                                    <tr>
                                        <td align="center" class="tbl_main" style="vertical-align:top;min-width:540px;width:540px;" valign="top">
                                            <table width="540" border="0" cellspacing="0" cellpadding="0" style="min-width:540px;width:540px;" class="tbl_main" align="center">
                                                <tr>
                                                    <td align="center" valign="top" bgcolor="#ffffff" style="background-color: #ffffff;border-radius:3px;-webkit-border-radius:3px; -moz-border-radius:3px;">
                                                        <img alt="LOGO" src="<?php echo base_url() ?>assets/images/logo.png" width="320px" style="margin-top: 2rem;" />
                                                        <table width="480" border="0" cellspacing="0" cellpadding="0" style="min-width:480px;width:480px;" class="tbl_main">
                                                            <tr>
                                                                <div style="width: 480px !important; border-radius: 0.25rem; padding: 1.5rem 1.5rem;">
                                                                    <div style="width: 100%;">
                                                                        <table>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div><?php echo $category; ?> Title&nbsp;:&nbsp;</div>
                                                                                    <div><?php echo $category_title; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Amount&nbsp;:&nbsp;</div>
                                                                                    <div style="text-transform: uppercase;"><?php echo $amount; ?><?php echo $currency; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Name&nbsp;:&nbsp;</div>
                                                                                    <div><?php echo $name; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Email&nbsp;:&nbsp;</div>
                                                                                    <div><?php echo $email; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Phone&nbsp;:&nbsp;</div>
                                                                                    <div><?php echo $phone; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Method&nbsp;:&nbsp;</div>
                                                                                    <div style="text-transform: uppercase;"><?php echo $brand; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Card Number&nbsp;:&nbsp;</div>
                                                                                    <div>****&nbsp;&nbsp;****&nbsp;&nbsp;****&nbsp;&nbsp;****&nbsp;&nbsp;<?php echo $card_number; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Date&nbsp;:&nbsp;</div>
                                                                                    <div><?php echo $date; ?></div>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; padding: 0.5rem 0.5rem; font-size:1.25rem;">
                                                                                    <div>Status&nbsp;:&nbsp;</div>
                                                                                    <div><span style="padding: 0.5rem 0.5rem; color: <?php echo $status_color; ?>; border-radius: 0.25rem; text-transform: capitalize;"><?php echo $status; ?></span></div>
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </div>
                                                                </div>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
</html>
