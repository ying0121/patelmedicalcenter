<script>
    const aaa = "This is global";

    const HEADER_BANNER = 'HEADER-BANNER';
    const CENTRAL = 'CENTRAL';
    const IMAGE_POSITION = {
        'Home': [HEADER_BANNER],
        'TheClinic': [HEADER_BANNER],
        'AboutUs': [HEADER_BANNER, CENTRAL],
        'Orientation': [HEADER_BANNER],
        'Vault': [HEADER_BANNER, CENTRAL],
        'Auth': [HEADER_BANNER],
    };
    const VIDEO_POSITION = {
        'Home': ['DEFAULT_POSITION'],
        'TheClinic': ['DEFAULT_POSITION']
    };
</script>


