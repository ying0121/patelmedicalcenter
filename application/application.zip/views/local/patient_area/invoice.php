<div class="row my-3 p-10 bg-white border rounded">
    <div class="col-12 mb-4 d-flex justify-content-between align-items-center my-5">
        <div>
            <h3>Invoice</h3>
        </div>
        <div><span class='add_invoice_btn btn btn-light-primary btn-icon'><i class='fa fa-plus'></i></span></div>
    </div>
    <div class="col-12">
        <table class="table" id="invoice_tb">
            <thead>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>